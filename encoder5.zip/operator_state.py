"""
Explicit operator state for replay and long recording (ReplayTrove appliance semantics).
"""

from __future__ import annotations

import json
import logging
from enum import Enum, auto
from pathlib import Path

logger = logging.getLogger("replaytrove.encoder")


class ReplayControlState(Enum):
    """Derived replay control state for gating save commands."""

    IDLE = auto()
    SAVING_REPLAY = auto()
    REPLAY_ACTIVE = auto()


class LongRecordState(Enum):
    NOT_RECORDING = auto()
    RECORDING = auto()


def read_scoreboard_replay_display_active(path: Path | None) -> bool:
    """
    True when the scoreboard reports replay slate / transition (blocks new replay saves).
    """
    if path is None:
        return False
    try:
        if not path.is_file():
            return False
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        return bool(data.get("replay_display_active", False))
    except (OSError, json.JSONDecodeError, TypeError):
        logger.debug("Could not read scoreboard state from %s", path, exc_info=True)
        return False
